package net.gemue.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PhotoSorter {
    public static final String JPG_FOLDER = "JPG";
    private String targetDir = "e:\\FOTOS\\Reisen\\2018 Nordstrand\\";
    private DateFormat format = new SimpleDateFormat("dd.MM.yyyy");

    public static void main(String[] args) {
        new PhotoSorter().listFiles();
    }

    private void listFiles() {
        File target = new File(targetDir);
        File[] files = target.listFiles();
        if (files != null) {
            int size = files.length;
            double currentPercent = 0;
            for (int i = 0; i < size; i++) {
                File file = files[i];
                float percent = (float) i / (float)size * 100f;
                if (Math.floor(percent) > currentPercent) {
                    currentPercent = Math.floor(percent);
                    System.out.println((int)currentPercent + "%");
                }
                if (!file.isDirectory()) {
                    String date = (format.format(new Date(file.lastModified())));
                    File dateDir = new File(target, date);
                    File jpgDir = new File(dateDir, JPG_FOLDER);
                    if (!dateDir.exists())
                        dateDir.mkdir();
                    if (!jpgDir.exists())
                        jpgDir.mkdirs();
                    String fileName = file.getName();
                    if (fileName.toLowerCase().endsWith("jpg"))
                        file.renameTo(new File(jpgDir, fileName));
                    else
                        file.renameTo(new File(dateDir, fileName));
                }
            }
            System.out.println("100%");
        }
    }
}
